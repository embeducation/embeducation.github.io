ltext = "Label\nthe\na\nand\nto\nhe\nwas\nof\nhis\nin\nHe\nthat\n--\non\nas\nhad\nDursley\nit\nhave\nat\nMr.\nI\nbe\nsaid\nProfessor\nall\nwere\nMrs.\nyou\ndidn't\nbut\nout\nIt\nbeen\nshe\nfor\nher\nthey\nDumbledore\nvery\npeople\nover\ninto\ncat\nMcGonagall\nnot\nHarry\nwith\nThe\nup\nback\nhim\nif\nthis\nso\nit.\nabout\ncouldn't\ndown\ntheir\nwould\ncould\nwhat\nnever\neven\nthem\n\n";

words = ltext.split("\n")

print (words)

